<?php

/**
 * Plugin Name: WooCommerce weely food delivery
 * Description: This plugin inserts the content of the woocommerce-custom-page.php file into a custom WooCommerce page.
 * Version: 1.0
 * Author: Sári Zoltán
 * Author URI: https://olcsoweboldal1.hu/
 * Plugin URI: https://olcsoweboldal1.hu/
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Register the custom WooCommerce page
function woocommerce_custom_page_shortcode($atts) {
    // Check if WooCommerce is active
    if (!class_exists('WooCommerce')) {
        return __('WooCommerce is not active on this site.', 'woocommerce-custom-page');
    }

    // Get the custom page content
    $custom_page_content = '';
    $custom_page_file = plugin_dir_path(__FILE__) . 'woocommerce-custom-page.php';

    if (file_exists($custom_page_file)) {
        ob_start();
        include($custom_page_file);
        $custom_page_content = ob_get_clean();
    } else {
       $custom_page_content = __('The woocommerce-custom-page.php file is not found in the plugin folder.', 'woocommerce-custom-page');
    }

    return $custom_page_content;
}
add_shortcode('woocommerce_custom_page', 'woocommerce_custom_page_shortcode');


// Add background color option for product categories
function custom_product_cat_add_fields() {
    ?>
    <div class="form-field term-background-color-wrap">
        <label for="term-background-color"><?php _e('Background color', 'woocommerce'); ?></label>
        <input type="text" id="term-background-color" name="term-background-color" value="#ffffff" pattern="(?i)^#(?:[0-9a-fA-F]{3}){1,2}$">
    </div>
    <?php
}
add_action('product_cat_add_form_fields', 'custom_product_cat_add_fields', 10, 2);

// Edit background color and exclude from table options for product categories
function custom_product_cat_edit_fields($term) {
    $term_id = $term->term_id;
    $background_color = get_term_meta($term_id, 'background-color', true);
    $exclude_from_table = get_term_meta($term->term_id, 'exclude_from_table', true);
    ?>
    <tr class="form-field term-background-color-wrap">
        <th scope="row"><label for="term-background-color"><?php _e('Background color', 'woocommerce'); ?></label></th>
        <td>
            <input type="text" id="term-background-color" name="term-background-color" value="<?php echo esc_attr($background_color); ?>" pattern="(?i)^#(?:[0-9a-fA-F]{3}){1,2}$">
        </td>
    </tr>
    <tr class="form-field term-exclude-from-table-wrap">
    <th scope="row"><label for="term-exclude-from-table"><?php _e('Exclude from Table', 'woocommerce'); ?></label></th>
    <td>
        <input type="checkbox" name="term-exclude-from-table" id="term-exclude-from-table" value="1" <?php checked($exclude_from_table, 1); ?> />
        <p class="description"><?php _e('Check this box if you want to hide this category from the table.', 'woocommerce'); ?></p>
    </td>
</tr>
    <?php
}
add_action('product_cat_edit_form_fields', 'custom_product_cat_edit_fields', 10, 2);

function custom_product_cat_save_fields($term_id) {
    // Save background color
    if (isset($_POST['term-background-color']) && preg_match("/^(?i)#(?:[0-9a-fA-F]{3}){1,2}$/", $_POST['term-background-color'])) {
        update_term_meta($term_id, 'background-color', sanitize_hex_color($_POST['term-background-color']));
    }

    // Save exclude from table
    if (isset($_POST['term-exclude-from-table'])) {
        update_term_meta($term_id, 'exclude_from_table', intval($_POST['term-exclude-from-table']));
    } else {
        delete_term_meta($term_id, 'exclude_from_table');
    }
}
add_action('create_product_cat', 'custom_product_cat_save_fields', 10, 2);
add_action('edited_product_cat', 'custom_product_cat_save_fields', 10, 2);





// Register the customizer settings
function woocommerce_custom_page_customizer_settings($wp_customize) {
    $wp_customize->add_section('woocommerce_custom_page_settings', array(
        'title'    => __('WooCommerce Custom Page Settings', 'woocommerce-custom-page'),

        'priority' => 120,
    ));

    $wp_customize->add_setting('woocommerce_custom_page_border_color', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'woocommerce_custom_page_border_color', array(
        'label'    => __('Border Color', 'woocommerce-custom-page'),

        'section'  => 'woocommerce_custom_page_settings',
        'settings' => 'woocommerce_custom_page_border_color',
    )));

    $wp_customize->add_setting('woocommerce_custom_page_border_width', array(
        'default'           => '0',
        'sanitize_callback' => 'absint',
    ));

    $wp_customize->add_control('woocommerce_custom_page_border_width', array(
        'label'    => __('Border Width', 'woocommerce-custom-page'),

        'section'  => 'woocommerce_custom_page_settings',
        'type'     => 'number',
    ));
}
add_action('customize_register', 'woocommerce_custom_page_customizer_settings');

// Enqueue the custom styles
function woocommerce_custom_page_styles() {
    $border_color = get_theme_mod('woocommerce_custom_page_border_color', '');
    $border_width = get_theme_mod('woocommerce_custom_page_border_width', '0');

    $custom_css = "
        .table.table-bordered.table-hover tbody tr td {
            border-color: {$border_color};
            border-width: {$border_width}px;
            border-style: solid;
        }";

    wp_add_inline_style('woocommerce-custom-page', $custom_css);
}
add_action('wp_enqueue_scripts', 'woocommerce_custom_page_styles', 20);


// Enqueue the scripts and styles
function enqueue_woocommerce_custom_page_assets() {
   /** wp_enqueue_style('woocommerce-custom-page', plugin_dir_url(__FILE__) . 'woocommerce-custom-page.css', array(), '1.0');**/
    wp_enqueue_script('woocommerce-custom-page', plugin_dir_url(__FILE__) . 'woocommerce-custom-page.php', array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'enqueue_woocommerce_custom_page_assets');

// Add a new menu item to the WordPress admin menu
function woocommerce_custom_page_admin_menu() {
    add_menu_page(
        __('WooCommerce Custom Shop Page', 'woocommerce-custom-page'), // Page title
        __('WooCommerce Custom Shop', 'woocommerce-custom-page'), // Menu title
        'manage_options', // Capability
        'woocommerce-custom-shop-page', // Menu slug
        'woocommerce_custom_page_admin_page', // Function that displays the page content
        'dashicons-cart', // Icon
        3 // Position
    );
}
add_action('admin_menu', 'woocommerce_custom_page_admin_menu');

function woocommerce_custom_page_admin_page() {
    ?>
    <div class="wrap">
    <h1 class="wp-heading-inline"><?php _e('WooCommerce Custom Shop Page', 'woocommerce-custom-page'); ?></h1>
    <hr class="wp-header-end">
    
    <img src="https://spfood.marylandwebdesign1.com/wp-content/uploads/2023/04/pluginhatter.jpg" alt="<?php esc_attr_e('Header Image', 'woocommerce-custom-page'); ?>" class="header-image">
    <p><?php _e('The WooCommerce Custom Shop Page plugin enables you to create a custom shop page in your WooCommerce online store.', 'woocommerce-custom-page'); ?></p>
    
    <h2 class="nav-tab-wrapper">
        <a href="#color" class="nav-tab nav-tab-active"><?php _e('Color settings', 'woocommerce-custom-page'); ?></a>
        <a href="#table" class="nav-tab"><?php _e('Table settings', 'woocommerce-custom-page'); ?></a>
    </h2>
</div>

        
        <div id="color" class="tab-content">
    <h3><?php _e('Add color to categories', 'woocommerce-custom-page'); ?></h3>
    <p><?php _e('The plugin allows you to set a custom background color for the rows of product categories in the table.', 'woocommerce-custom-page'); ?></p>
    <p><?php _e('To do this, follow these steps:', 'woocommerce-custom-page'); ?></p>
    <ol>
        <li><?php _e('Go to Products > Categories in the menu.', 'woocommerce-custom-page'); ?></li>
        <li><?php _e("Click on the 'Edit' button next to the category you want.", 'woocommerce-custom-page'); ?></li>
        <li><?php _e("Select the desired background color in the 'Background color' field on the page.", 'woocommerce-custom-page'); ?></li>
        <li><?php _e("Click the 'Update' button to save your changes.", 'woocommerce-custom-page'); ?></li>
    </ol>
</div>
<div id="table" class="tab-content" style="display:none;">
    <h3><?php _e('Size the table border and thickness', 'woocommerce-custom-page'); ?></h3>
    <p><?php _e('In this section you will find how to resize the border and thickness of the table.', 'woocommerce-custom-page'); ?></p>
    <ol>
        <li><?php _e('Go to "Appearance > Customize" in the WordPress admin interface.', 'woocommerce-custom-page'); ?></li>
        <li><?php _e('Click on the "WooCommerce Custom Shop Page" section.', 'woocommerce-custom-page'); ?></li>
        <li><?php _e('In this section, you can adjust the border thickness and color of the table.', 'woocommerce-custom-page'); ?></li>
        <li><?php _e('Once you have set the desired values, click the "Publish" button to save the changes.', 'woocommerce-custom-page'); ?></li>
    </ol>
</div>

    
    
    <script>
        (function() {
            var tabs = document.querySelectorAll('.nav-tab');
            var tabContents = document.querySelectorAll('.tab-content');
            
            function switchTab(event) {
                event.preventDefault();
                var targetId = this.getAttribute('href');
                
                tabs.forEach(function(tab) {
                    tab.classList.remove('nav-tab-active');
                });
                this.classList.add('nav-tab-active');
                
                tabContents.forEach(function(content) {
                    content.style.display = 'none';
                });
                document.querySelector(targetId).style.display = 'block';
            }
            
            tabs.forEach(function(tab) {
                tab.addEventListener('click', switchTab);
            });
        })();
    </script>
    
    <style>
        .header-image {
            width: 100%;
            max-width: 800px;
            height: auto;
            display: block;
            margin-bottom: 20px;
        }
        .image-gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }
        .image {
            width: 100%;
            max-width: 200px;
            height: auto;
        }
        .tab-content {
            margin-bottom: 20px;
        }
    </style>
</div>
<?php
}
/**Translate**/
function my_plugin_load_textdomain() {
    load_plugin_textdomain('woocommerce-custom-page', false, basename(dirname(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'my_plugin_load_textdomain');

foreach (array('pre_term_name') as $filter) {
    remove_filter($filter, 'sanitize_text_field');
    remove_filter($filter, 'wp_filter_kses');
    remove_filter( $filter, '_wp_specialchars', 30 );
}

/**hetek**/
function week_number_custom_meta() {
    add_meta_box('week_number_meta', 'Week Number', 'week_number_meta_callback', 'page', 'side', 'high');
}
add_action('add_meta_boxes', 'week_number_custom_meta');

function week_number_meta_callback($post) {
    wp_nonce_field(basename(__FILE__), 'week_number_nonce');
    $week_number = get_post_meta($post->ID, 'week_number', true);
    echo '<label for="week_number">Week Number: </label>';
    echo '<input type="number" id="week_number" name="week_number" value="' . esc_attr($week_number) . '" min="1" max="52">';
}

function save_week_number_meta($post_id) {
    if (!isset($_POST['week_number_nonce']) || !wp_verify_nonce($_POST['week_number_nonce'], basename(__FILE__))) {
        return $post_id;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }
    if ('page' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return $post_id;
        }
    } else {
        if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }
    }
    $week_number = $_POST['week_number'];
    update_post_meta($post_id, 'week_number', $week_number);
}
add_action('save_post', 'save_week_number_meta');

add_action('woocommerce_product_options_general_product_data', 'add_week_number_product_field');
function add_week_number_product_field() {
    echo '<div class="options_group">';
    woocommerce_wp_text_input(
        array(
            'id' => 'week_number',
            'label' => __('Week Number', 'woocommerce'),
            'placeholder' => '1',
            'desc_tip' => 'true',
            'description' => __('Enter the week number for this product.', 'woocommerce'),
            'type' => 'number',
            'custom_attributes' => array(
                'step' => '1',
                'min' => '1',
                'max' => '52',
            ),
        )
    );
    echo '</div>';
}

add_action('woocommerce_process_product_meta', 'save_week_number_product_field');
function save_week_number_product_field($post_id) {
    $week_number = isset($_POST['week_number']) ? $_POST['week_number'] : '';
    update_post_meta($post_id, 'week_number', $week_number);
}

function custom_register_week_number_meta() {
    register_meta('post', 'week_number', array(
        'show_in_rest' => true,
        'single' => true,
        'type' => 'integer',
    ));
}
add_action('init', 'custom_register_week_number_meta');

/**rendelési határidők**/
function order_deadline_custom_meta() {
    add_meta_box('order_deadline_meta', 'Order Deadline', 'order_deadline_meta_callback', 'page', 'side', 'high');
}
add_action('add_meta_boxes', 'order_deadline_custom_meta');

function order_deadline_meta_callback($post) {
    wp_nonce_field(basename(__FILE__), 'order_deadline_nonce');
    $order_deadline_value = get_post_meta($post->ID, 'order_deadline_value', true);
    echo '<label for="order_deadline_value">Order Deadline: </label>';
    echo '<input type="text" id="order_deadline_value" name="order_deadline_value" value="' . esc_attr($order_deadline_value) . '">';
}

function save_order_deadline_meta($post_id) {
    if (!isset($_POST['order_deadline_nonce']) || !wp_verify_nonce($_POST['order_deadline_nonce'], basename(__FILE__))) {
        return $post_id;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }
    if ('page' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return $post_id;
        }
    } else {
        if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }
    }
    $order_deadline = $_POST['order_deadline_value'];
    update_post_meta($post_id, 'order_deadline_value', $order_deadline);
}
add_action('save_post', 'save_order_deadline_meta');

function get_week_start_date($week_number) {
    $current_date = new DateTime();
    $current_week_number = (int) $current_date->format('W');
    $week_diff = $week_number - $current_week_number;
    $week_start = $current_date->modify("+$week_diff weeks")->modify('monday this week')->setTime(0, 0, 0);
    return $week_start;
}

function load_lightbox_assets() {
    wp_enqueue_style('lightbox', 'https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css');
    wp_enqueue_script('lightbox-plus-jquery', 'https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js', array('jquery'), '', true);
}
add_action('wp_enqueue_scripts', 'load_lightbox_assets');


/**egyedi funkciók a friisfoodnak**/

/**saját css*/
function enqueue_custom_scripts_and_styles() {
    // Hozzáadás a saját CSS fájlt
     wp_enqueue_style('frissfood', plugins_url('woocommerce-custom-page/css/plugin.css'), array(), '1.0.0');
	wp_enqueue_script('tippy', 'https://unpkg.com/@popperjs/core@2.9.3/dist/umd/popper.min.js', array(), '2.9.3', true);
    wp_enqueue_script('popper', 'https://unpkg.com/tippy.js@6.3.1/dist/tippy-bundle.umd.min.js', array('tippy'), '6.3.1', true);
    wp_enqueue_style('tippy', 'https://unpkg.com/tippy.js@6.3.1/themes/light.css', array(), '6.3.1');
	 wp_enqueue_style( 'bootstrap-custom', get_template_directory_uri() . '/css/bootstrap-custom.css' );
    
    // ...a többi wp_enqueue_script és wp_enqueue_style hívás
}

add_action('wp_enqueue_scripts', 'enqueue_custom_scripts_and_styles');

/**nutrion**/

// Hozzáadunk egy új metaadat mezőt a termék szerkesztő felülethez
add_action('woocommerce_product_options_general_product_data', 'add_custom_nutrition_meta_field');
function add_custom_nutrition_meta_field() {
    // HTML szerkesztő hozzáadása
    echo '<div class="options_group">';
    echo '<h2>Táplálkozási információ HTML szerkesztő</h2>';
    $editor_id = '_nutrition_information_editor';
    wp_editor(htmlspecialchars_decode(get_post_meta(get_the_ID(), '_nutrition_information', true)), $editor_id, array(
        'textarea_name' => '_nutrition_information',
        'editor_class' => 'custom-nutrition-information-editor',
        'wpautop' => false,
        'media_buttons' => true,
        'textarea_rows' => 5,
    ));
    echo '</div>';
}

// Mentjük az egyéni metaadat mező értékét a termék szerkesztésekor
add_action('woocommerce_process_product_meta', 'save_custom_nutrition_meta_field');
function save_custom_nutrition_meta_field($post_id) {
    $nutrition_information = isset($_POST['_nutrition_information']) ? $_POST['_nutrition_information'] : '';
    update_post_meta($post_id, '_nutrition_information', $nutrition_information);
    update_post_meta($post_id, 'your_nutrition_meta_key', $nutrition_information);
}

// Megjelenítjük a táplálkozási információt a termékoldalon
add_action('woocommerce_single_product_summary', 'display_custom_nutrition_information', 25);
function display_custom_nutrition_information() {
    global $product;
    $nutrition_information = get_post_meta($product->get_id(), 'your_nutrition_meta_key', true);
    if (!empty($nutrition_information)) {
        $decoded_nutrition_information = htmlspecialchars_decode(stripslashes($nutrition_information));
        echo '<div class="custom-nutrition-information">' . wp_kses_post($decoded_nutrition_information) . '</div>';
    }
}

/**  Extra fields**/
// Hozzáadunk egy új metaadat mezőt a termék szerkesztő felülethez
add_action('woocommerce_product_options_general_product_data', 'add_custom_extra_info_meta_field');
function add_custom_extra_info_meta_field() {
    // HTML szerkesztő hozzáadása
    echo '<div class="options_group">';
    echo '<h2>Extra információ HTML szerkesztő</h2>';
    $editor_id = '_extra_information_editor';
    wp_editor(htmlspecialchars_decode(get_post_meta(get_the_ID(), '_extra_information', true)), $editor_id, array(
        'textarea_name' => '_extra_information',
        'editor_class' => 'custom-extra-information-editor',
        'wpautop' => false,
        'media_buttons' => true,
        'textarea_rows' => 5,
    ));
    echo '</div>';
}

// Mentjük az egyéni metaadat mező értékét a termék szerkesztésekor
add_action('woocommerce_process_product_meta', 'save_custom_extra_info_meta_field');
function save_custom_extra_info_meta_field($post_id) {
    $extra_information = isset($_POST['_extra_information']) ? $_POST['_extra_information'] : '';
    update_post_meta($post_id, '_extra_information', $extra_information);
    update_post_meta($post_id, 'your_extra_info_meta_key', $extra_information);
}

// Megjelenítjük az extra információt a termékoldalon
add_action('woocommerce_single_product_summary', 'display_custom_extra_information', 25);
function display_custom_extra_information() {
    global $product;
    $extra_information = get_post_meta($product->get_id(), 'your_extra_info_meta_key', true);
    if (!empty($extra_information)) {
        $decoded_extra_information = htmlspecialchars_decode(stripslashes($extra_information));
        echo '<div class="custom-extra-information">' . wp_kses_post($decoded_extra_information) . '</div>';
    }
}
/**  Extra fields**/


/**cimkek**/
function get_product_tags_list( $product ) {
    $product_tags = get_the_terms( $product->get_id(), 'product_tag' );

    if ( $product_tags && ! is_wp_error( $product_tags ) ) {
        $tags_list = array();

        foreach ( $product_tags as $tag ) {
            $tags_list[] = $tag->name;
        }

        return join( ', ', $tags_list );
    }

    return '';
}
/**qweri**/
function load_jquery() {
    if (!is_admin()) {
        wp_enqueue_script('jquery');
    }
}
add_action('wp_enqueue_scripts', 'load_jquery');


/**
function wpse_292293_quantity_input_default( $args, $product ) {
    $args['input_value'] = 0;

    return $args;
}
add_filter( 'woocommerce_quantity_input_args', 'wpse_292293_quantity_input_default', 10, 2 );

**/
function custom_cart_item_quantity_input($input, $cart_item, $cart_item_key) {
    if (!is_array($cart_item)) {
        return $input;
    }
    
    $product = isset($cart_item['data']) && is_object($cart_item['data']) ? $cart_item['data'] : null;
    if (!$product) {
        return $input;
    }

    $input_id = uniqid('quantity_');
    $input_name = "cart[{$cart_item_key}][qty]";

    return woocommerce_quantity_input(array(
        'input_name'  => $input_name,
        'input_value' => isset($cart_item['quantity']) ? $cart_item['quantity'] : 1,
        'max_value'   => $product->get_max_purchase_quantity(),
        'min_value'   => '0',
        'step'        => apply_filters('woocommerce_quantity_input_step', '1', $product),
        'pattern'     => apply_filters('woocommerce_quantity_input_pattern', has_filter('woocommerce_stock_amount', 'intval') ? '[0-9]*' : ''),
        'inputmode'   => apply_filters('woocommerce_quantity_input_inputmode', has_filter('woocommerce_stock_amount', 'intval') ? 'numeric' : ''),
        'product_name' => $product->get_title(),
    ), $product, false);
}
add_filter('woocommerce_cart_item_quantity', 'custom_cart_item_quantity_input', 10, 3);

/**rövid
function excerpt_in_cart($cart_item_html, $product_data) {
global $_product;

$excerpt = get_the_excerpt($product_data['product_id']);
$excerpt = substr($excerpt, 0, 80);

echo $cart_item_html . '<br><p class="shortDescription">' . $excerpt . '' . '</p>';
}

add_filter('woocommerce_cart_item_name', 'excerpt_in_cart', 40, 2);**/

/**Multicart**/
function multi_add_to_cart() {
    // Ellenőrizd a nonce-t
    check_ajax_referer('multi_add_to_cart', 'nonce');

    // Olvasd be a termékeket a kérésből
    $products = isset($_POST['products']) ? json_decode(stripslashes($_POST['products']), true) : array();

    // Ha nincsenek termékek, akkor hiba
    if (empty($products)) {
        wp_send_json_error('Nincsenek termékek a kosárba helyezéshez.');
    }

    // Kosárba helyezés
    foreach ($products as $product) {
        WC()->cart->add_to_cart($product['product_id'], $product['quantity']);
    }

    // Sikeres válasz
    wp_send_json_success();
}

add_action('wp_ajax_multi_add_to_cart', 'multi_add_to_cart');
add_action('wp_ajax_nopriv_multi_add_to_cart', 'multi_add_to_cart');
/**delivery date**/


/**idő*/


function frissfood_add_delivery_date_time_field($checkout) {
    echo '<div id="frissfood_delivery_date_time_field"><h3>' . __('Desired delivery date and time', 'woocommerce') . '</h3>';

    woocommerce_form_field('frissfood_delivery_date', array(
        'type' => 'date',
        'class' => array('form-row-wide'),
        'label' => __('Select a delivery date'),
        'placeholder' => __('ÉÉÉÉ-HH-NN'),
    ), $checkout->get_value('frissfood_delivery_date'));

    woocommerce_form_field('frissfood_delivery_time', array(
        'type' => 'select',
        'class' => array('form-row-wide'),
        'label' => __('Select the delivery time interval'),
        'options' => array(
            '' => __('Choose a time interval'),
            '07:00-08:00' => '07:00-08:00',
            '08:00-09:00' => '08:00-09:00',
            '10:00-11:00' => '10:00-11:00',
            '12:00-13:00' => '12:00-13:00',
            '13:00-14:00' => '13:00-14:00',
            '14:00-15:00' => '14:00-15:00',
            '15:00-16:00' => '15:00-16:00',
            '16:00-17:00' => '16:00-17:00',
                       
        ),
    ), $checkout->get_value('frissfood_delivery_time'));

    echo '</div>';
}
add_action('woocommerce_after_order_notes', 'frissfood_add_delivery_date_time_field');

function frissfood_save_delivery_date_time_field($order_id) {
    if (!empty($_POST['frissfood_delivery_date'])) {
        update_post_meta($order_id, 'frissfood_delivery_date', sanitize_text_field($_POST['frissfood_delivery_date']));
    }
    if (!empty($_POST['frissfood_delivery_time'])) {
        update_post_meta($order_id, 'frissfood_delivery_time', sanitize_text_field($_POST['frissfood_delivery_time']));
    }
}
add_action('woocommerce_checkout_update_order_meta', 'frissfood_save_delivery_date_time_field');

function frissfood_display_delivery_date_time_in_admin($order) {
    $delivery_date = get_post_meta($order->get_id(), 'frissfood_delivery_date', true);
    $delivery_time = get_post_meta($order->get_id(), 'frissfood_delivery_time', true);

    if ($delivery_date) {
        echo '<p><strong>' . __('Desired delivery date', 'woocommerce') . ':</strong> ' . $delivery_date . '</p>';
    }
    if ($delivery_time) {
        echo '<p><strong>' . __('Desired delivery time interval', 'woocommerce') . ':</strong> ' . $delivery_time . '</p>';
    }
}
add_action('woocommerce_admin_order_data_after_billing_address', 'frissfood_display_delivery_date_time_in_admin');

add_action('woocommerce_admin_order_data_after_billing_address', 'frissfood_display_delivery_date_time_in_admin');

/**table-nutrion**/
// Engedélyezzük a <table> elemet az wp_kses_post() függvényben
add_filter('wp_kses_allowed_html', 'add_table_to_wp_kses_allowed_html', 10, 2);
function add_table_to_wp_kses_allowed_html($allowedposttags, $context) {
    if ($context == 'post') {
        $allowedposttags['table'] = array(
            'class' => true,
            'id' => true,
            'style' => true,
        );
        $allowedposttags['thead'] = array();
        $allowedposttags['tbody'] = array();
        $allowedposttags['tr'] = array();
        $allowedposttags['th'] = array(
            'colspan' => true,
            'rowspan' => true,
            'scope' => true,
            'class' => true,
            'id' => true,
            'style' => true,
        );
        $allowedposttags['td'] = array(
            'colspan' => true,
            'rowspan' => true,
            'headers' => true,
            'class' => true,
            'id' => true,
            'style' => true,
        );
    }
    return $allowedposttags;
}
/**ketego**/

// Add custom shortcode for WooCommerce custom page with category ID
function woocommerce_custom_page_with_category_id_shortcode($atts) {
    // Check if WooCommerce is active
    if (!class_exists('WooCommerce')) {
        return __('WooCommerce is not active on this site.', 'woocommerce-custom-page');
    }

    // Get the custom page content
    $custom_page_content = '';
    $custom_page_file = plugin_dir_path(__FILE__) . 'woocommerce-custom-page.php';

    if (file_exists($custom_page_file)) {
        // Get the category ID from the shortcode
        $category_id = isset($atts['category_id']) ? absint($atts['category_id']) : 0;
        $category = get_term($category_id, 'product_cat');
        
        if (!$category) {
            return __('The specified product category does not exist.', 'woocommerce-custom-page');
        }
        
        // Set up the query arguments for the products in the category
        $query_args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $category_id
                )
            )
        );
        
        // Get the products in the category
        $products = new WP_Query($query_args);
        
        // Get the custom page content
        ob_start();
        include($custom_page_file);
        $custom_page_content = ob_get_clean();
    } else {
       $custom_page_content = __('The woocommerce-custom-page.php file is not found in the plugin folder.', 'woocommerce-custom-page');
    }

    return $custom_page_content;
}
add_shortcode('woocommerce_custom_page_id', 'woocommerce_custom_page_with_category_id_shortcode');

/** egyedi kosár oldal**/





function custom_cart_page() {
    if ( is_cart() ) {
        $cart_template = plugin_dir_path( __FILE__ ) . 'woocommerce/templates/cart/cart.php';
        if ( file_exists( $cart_template ) ) {
            ob_start();

            // Betöltjük a WooCommerce fejlécét és stílusát
            wc_get_template_part( 'header', 'cart' );
            wp_enqueue_style( 'woocommerce-cart' );

            // Betöltjük az adott téma style.css fájlját
            wp_enqueue_style( 'custom-theme-style', get_template_directory_uri() . '/style.css' );

            // Betöltjük a kosár oldal tartalmát
            include $cart_template;

            // Kiürítjük a buffer tartalmát
            ob_end_flush();
            exit;
        }
    }
}
add_action( 'template_redirect', 'custom_cart_page' );







