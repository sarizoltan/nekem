<?php
/**
 * Cart Page
 *
 * @package WooCommerce\Templates
 * @version 7.8.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_cart' ); ?>
<form class="woocommerce-cart-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
	<?php do_action( 'woocommerce_before_cart_table' ); ?>

	<table class="shop_table shop_table_responsive cart woocommerce-cart-form__contents" cellspacing="0">
		<thead>
			<tr>
				<th class="product-remove"></th>
				<th class="product-thumbnail"></th>
				<th class="product-name"><?php esc_html_e( 'Product', 'woocommerce' ); ?></th>
				<th class="product-price"><?php esc_html_e( 'Price', 'woocommerce' ); ?></th>
				<th class="product-quantity"><?php esc_html_e( 'Quantity', 'woocommerce' ); ?></th>
				<th class="product-subtotal"><?php esc_html_e( 'Subtotal', 'woocommerce' ); ?></th>
				<th class="product-tags"><?php echo __( 'Menu', 'woocommerce-custom-page' ) . '<hr>' . __( 'Date', 'woocommerce-custom-page' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php do_action( 'woocommerce_before_cart_contents' ); ?>

			<?php
			foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
				$_product   = $cart_item['data'];
				$product_id = $cart_item['product_id'];

				if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 ) {
					$product_permalink = $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '';
					?>
					<tr class="woocommerce-cart-form__cart-item">
						<td class="product-remove">
							<a href="<?php echo esc_url( wc_get_cart_remove_url( $cart_item_key ) ); ?>" class="remove">&times;</a>
						</td>

						<td class="product-thumbnail">
							<?php
							$thumbnail = $_product->get_image();
							if ( ! $product_permalink ) {
								echo $thumbnail;
							} else {
								printf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $thumbnail );
							}
							?>
						</td>

						<td class="product-name">
							<?php
							if ( ! $product_permalink ) {
								echo wp_kses_post( $_product->get_name() );
							} else {
								printf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $_product->get_name() );
							}

							// Meta adatok (ha vannak)
							echo wc_get_formatted_cart_item_data( $cart_item );
							?>
						</td>

						<td class="product-price">
							<?php echo WC()->cart->get_product_price( $_product ); ?>
						</td>

						<td class="product-quantity" data-title="<?php esc_attr_e( 'Quantity', 'woocommerce' ); ?>">
						<?php
						if ( $_product->is_sold_individually() ) {
							$min_quantity = 1;
							$max_quantity = 1;
						} else {
							$min_quantity = 0;
							$max_quantity = $_product->get_max_purchase_quantity();
						}

						$product_quantity = woocommerce_quantity_input(
							array(
								'input_name'   => "cart[{$cart_item_key}][qty]",
								'input_value'  => $cart_item['quantity'],
								'max_value'    => $max_quantity,
								'min_value'    => $min_quantity,
								'product_name' => $product_name,
							),
							$_product,
							false
						);

						echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item ); // PHPCS: XSS ok.
						?>
						</td>


						<td class="product-subtotal">
							<?php echo WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ); ?>
						</td>

						<td class="product-tags">
    <?php
    // Termék címkék megjelenítése
    $product_tags = wc_get_product_tag_list( $product_id, '<span class="product-tags">', ', ', '</span>' );
    if ( ! empty( $product_tags ) ) {
        echo $product_tags;
    }

    // Hét számának kiolvasása és megjelenítése
    $week_number = get_post_meta( $product_id, 'week_number', true );

    if ( ! empty( $week_number ) ) {
        echo '<br><span class="week-number">Week ' . esc_html( $week_number ) . '</span>';
    } else {
        echo '<br><span class="week-number">N/A</span>'; // Ha nincs beállítva hét szám
    }
    ?>
</td>

					</tr>
					<?php
				}
			}
			?>

			<?php do_action( 'woocommerce_cart_contents' ); ?>

			<tr>
				<td colspan="6" class="actions">
					<?php if ( wc_coupons_enabled() ) { ?>
						<div class="coupon">
							<label for="coupon_code"><?php esc_html_e( 'Coupon:', 'woocommerce' ); ?></label> 
							<input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Coupon code', 'woocommerce' ); ?>" /> 
							<button type="submit" class="button" name="apply_coupon"><?php esc_html_e( 'Apply coupon', 'woocommerce' ); ?></button>
							<?php do_action( 'woocommerce_cart_coupon' ); ?>
						</div>
					<?php } ?>

<button type="submit" class="button" name="update_cart"><?php esc_html_e( 'Update cart', 'woocommerce' ); ?></button>
					<?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
				</td>
			</tr>

			<?php do_action( 'woocommerce_after_cart_contents' ); ?>
		</tbody>
	</table>

	<?php do_action( 'woocommerce_after_cart_table' ); ?>
</form>

<?php do_action( 'woocommerce_before_cart_collaterals' ); ?>

<div class="cart-collaterals">
	<?php do_action( 'woocommerce_cart_collaterals' ); ?>
</div>

<?php do_action( 'woocommerce_after_cart' ); ?>
