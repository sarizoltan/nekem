<?php
/**
 * Template Name: WooCommerce Custom Shop
 * Template Post Type: page
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

get_header('shop'); ?>
<style>

    
</style>
<!-- Bootstrap CSS -->
<!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-pzjw8f+ua7Kw1TIq0v8FqFjcJ6pajs/rzUw8f+ua7Kw1TIq0v8FqFjcJ6pajs/rzUw7" crossorigin="anonymous">-->
<link rel='stylesheet' id='lightbox-css' href='https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css' type='text/css' media='all' />
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js' id='lightbox-plus-jquery-js'></script>


<!-- Revolution Slider -->
<?php
// At the beginning of the template, before the main tag:
$week_number = get_post_meta(get_the_ID(), 'week_number', true);
?>


<!-- Main content -->
<main class="foodmenu">
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
  <div class="scroll-x">
    <table class="table table-bordered table-hover">
    <thead>
        
    <tr>
        <th scope="col" rowspan="2" class="menunev"><?php echo __("Menu", "woocommerce-custom-page"); ?><hr><?php echo __("Date", "woocommerce-custom-page"); ?></th>

        <?php
        $week_number = get_post_meta(get_the_ID(), 'week_number', true);
        $week_start = get_week_start_date($week_number);
        $days = array();
        for ($i = 0; $i < 7; $i++) {
        $days[] = $week_start->format('Y.m.d') . ' ' . $week_start->format('l');
        $week_start->modify('+1 day');
    }

    foreach ($days as $day) {
        $day_parts = explode(' ', $day);
        echo '<th scope="col">' . $day_parts[1] . '</th>';
    }
    ?>
</tr>
<tr>
    <?php
    foreach ($days as $day) {
        $day_parts = explode(' ', $day);
        echo '<th scope="col">' . $day_parts[0] . '</th>';
    }
    ?>
</tr>
<tr>
   <th scope="col" class="menunev"><?php echo __("Order Deadline", "woocommerce-custom-page"); ?></th>
    <?php
    $order_deadline_value = get_post_meta(get_the_ID(),'order_deadline_value', true);
$order_deadlines = explode(',', $order_deadline_value);
for ($i = 0; $i < 7; $i++): ?>

<th scope="col">
<?php echo isset($order_deadlines[$i]) ? esc_html($order_deadlines[$i]) : ''; ?>
</th>
<?php endfor; ?>
</tr>
</thead>
  <tbody>
      
      


      
    <?php
$color_index = 1;
$args = array(
  'taxonomy' => 'product_cat',
  'hide_empty' => false,
  'meta_query' => array(
        'relation' => 'OR',
        array(
            'key' => 'exclude_from_table',
            'compare' => 'NOT EXISTS'
        ),
        array(
            'key' => 'exclude_from_table',
            'value' => '1',
            'compare' => '!='
        )
  )
);

if (isset($atts['category_id'])) {
  $args['include'] = $atts['category_id'];
}

$product_categories = get_terms($args);



$days = array(
    __("Monday", "woocommerce-custom-page"),
    __("Tuesday", "woocommerce-custom-page"),
    __("Wednesday", "woocommerce-custom-page"),
    __("Thursday", "woocommerce-custom-page"),
    __("Friday", "woocommerce-custom-page"),
    __("Saturday", "woocommerce-custom-page"),
    __("Sunday", "woocommerce-custom-page"),
);

foreach ($product_categories as $product_category) {
  $background_color = get_term_meta($product_category->term_id, 'background-color', true);
  echo '<tr class="table-row" style="background-color: ' . esc_attr($background_color) . ';">';
  echo '<td>' . $product_category->name . '</td>';

  foreach ($days as $day) {$products_args = array(
'post_type' => 'product',
'posts_per_page' => 1,
'meta_query' => array(
'relation' => 'AND',
array(
'key' => 'week_number',
'value' => $week_number,
'compare' => '=',
),
),
'tax_query' => array(
'relation' => 'AND',
array(
'taxonomy' => 'product_cat',
'field' => 'term_id',
'terms' => $product_category->term_id,
),
array(
'taxonomy' => 'product_tag',
'field' => 'name',
'terms' => $day,
),
),
);
    $products = new WP_Query($products_args);

    if ($products->have_posts()) {
      while ($products->have_posts()) {
        $products->the_post();
        global $product;
?>
        
        
        
        <td class="td-height">
      <?php  echo do_shortcode('[custom_star_rating]'); ?>

</div>
            
            
            
            
            
                  <div class="product-thumbnail">
    <a href="<?php echo wp_get_attachment_image_url($product->get_image_id(), 'full'); ?>" data-lightbox="product-gallery" class="product-image-link">
        <?php the_post_thumbnail('woocommerce_thumbnail', ['class' => 'rounded-image']); ?>
    </a>
</div>


<div class="product-title custom-title"><?php echo get_the_title(); ?></div>
<div class="tapi">
    <?php
    $tooltip_text = get_post_meta(get_the_ID(), 'your_nutrition_meta_key', true);
    if ($tooltip_text) {
        // A 'data-tippy-content' attribútum értékét közvetlenül adjuk hozzá a 'wp_kses_post()' függvénnyel.
        echo '<a class="label label-danger" data-tippy-content="' . wp_kses_post($tooltip_text) . '">Ingredients</a>';
    }
    ?>
</div>
<div class="extra-info">
    <?php
    $extra_info = get_post_meta(get_the_ID(), 'your_extra_info_meta_key', true);
    if ($extra_info) {
        $decoded_extra_info = htmlspecialchars_decode(stripslashes($extra_info));
        echo '<div class="product-extra-info">' . wp_kses_post($decoded_extra_info) . '</div>';
    }
    ?>
</div>



<div class="product-price-wrapper">
<div class="product-price"><?php echo $product->get_price_html(); ?></div>
<form id="multi_add_to_cart_form" method="post">
<?php if (!$product->is_sold_individually()) {
                             woocommerce_quantity_input(array(
                               'min_value' => apply_filters('woocommerce_quantity_input_min', 0, $product),
                               'max_value' => apply_filters('woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product),
                               'input_id' => 'product_quantity'
                             ));
                           }
                          ?>
                         
</form>
</div>
<input type="checkbox" class="product-checkbox" value="<?php echo esc_attr($product->get_id()); ?>">
</td>

<?php
}
} else {
echo '<td></td>';
}
}
  echo '</tr>';
  $color_index++;
  if ($color_index > 100) {
    $color_index = 1;
  }
}
?>

</tbody>
</table>

<form id="multi-add-to-cart-form">
    <button type="submit" class="button alt" id="add_to_cart_button"><?php _e('Add all selected products to cart', 'woocommerce-custom-page'); ?></button>

</form>
</div> </div>
        
        
    </div>
</div>


</main>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz4fnFO9gybB2AmY2E2xi1z8aCxM5JCd6OSbxAWf//j46z5m5/1d6F7Gbd" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0v8FqFjcJ6pajs/rzUw8f+ua7Kw1TIq0v8FqFjcJ6pajs/rzUw7" crossorigin="anonymous"></script>
<script type="text/javascript">
document.getElementById('multi-add-to-cart-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const checkboxes = document.querySelectorAll('.product-checkbox:checked');
    const products = [];

    checkboxes.forEach(function(checkbox) {
        const productId = checkbox.value;
        const quantityInput = checkbox.closest('td').querySelector('.quantity input');
        const quantity = quantityInput ? parseInt(quantityInput.value, 10) : 1;

        products.push({ product_id: productId, quantity: quantity });
    });

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '<?php echo admin_url('admin-ajax.php'); ?>', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
    const response = JSON.parse(xhr.responseText);
    if (response.success) {
        alert('<?php echo esc_js( __("The selected products have been successfully added to the cart.", "woocommerce-custom-page") ); ?>');
        window.location.href = "<?php echo wc_get_cart_url(); ?>";
    } else {
        alert('<?php echo esc_js( __("An error occurred while adding products. Please try again.", "woocommerce-custom-page") ); ?>');
    }
} else {
    alert('<?php echo esc_js( __("An error occurred while adding products. Please try again.", "woocommerce-custom-page") ); ?>');
}

    };

    xhr.send('action=multi_add_to_cart&products=' + encodeURIComponent(JSON.stringify(products)) + '&nonce=<?php echo wp_create_nonce('multi_add_to_cart'); ?>');
});
</script>
<script>
jQuery(document).ready(function ($) {
    // Select all products check box
    const productCheckboxes = $('.product-checkbox');

    // Add event listener for each product tick
    productCheckboxes.on('change', function () {
        // Select the product cell
        const productCell = $(this).closest('td');

        // If the box is checked, add a 'selected' class to the cell
        if ($(this).is(':checked')) {
            productCell.addClass('selected');
        }
        // If the check box is unchecked, remove the 'selected' class from the cell
        else {
            productCell.removeClass('selected');
        }
    });
});


</script>
<script>
   jQuery(document).ready(function ($) {
    // Hozzáadjuk a data-tippy-content attribútumot az összes olyan képhez, amelynek van alt attribútuma
    $('img[alt]').each(function() {
        const altText = $(this).attr('alt');
        if (altText) {
            $(this).attr('data-tippy-content', altText);
        }
    });

    // Módosított Tippy inicializálás, hogy kezelje a data-tippy-html attribútumot és a képek esetében a data-tippy-content attribútumot
    tippy('[data-tippy-content], [data-tippy-html]', {
        theme: 'light',
        animation: 'shift-toward',
        delay: [400, 400],
        allowHTML: true, // Engedélyezzük a HTML használatát a tooltipben
        content(reference) {
            const title = reference.getAttribute('data-tippy-html');
            if (title) {
                return document.querySelector(title).innerHTML;
            }
            return reference.getAttribute('data-tippy-content');
        },
        interactive: true, // Engedélyezi az interaktív mód használatát a tooltipben
        trigger: 'click', // A tooltip akkor jelenjen meg, ha rákattintunk a referenciaelemre
        hideOnClick: true, // Az overlay csak akkor záródjon be, ha a felhasználó rákattint az "X" gombra
        onHidden(instance) {
            instance.setContent(reference.getAttribute('data-tippy-content')); // Visszaállítjuk a tooltip tartalmát az eredeti szövegre
        },
    });
});
        // Initialize lightbox
      //  $('a[data-lightbox="product-image"]').simpleLightbox();
  // });
</script>

</script>
<script>jQuery(document).ready(function ($) {
    $('.product-image-link').simpleLightbox();
});</script>

<script src="https://unpkg.com/@popperjs/core@2"></script>
<script src="https://unpkg.com/tippy.js@6"></script>