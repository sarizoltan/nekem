<?php

function woocommerce_custom_page_shortcode_updated($atts)
{
    $atts = shortcode_atts(
        array(
            'id' => 0,
        ),
        $atts,
        'woocommerce_custom_page'
    );

    if (!$atts['id']) {
        return '';
    }

    ob_start();

    $args = array(
        'p' => $atts['id'],
        'post_type' => 'page',
        'posts_per_page' => 1,
    );

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            get_template_part('woocommerce-custom-page');
        }
        wp_reset_postdata();
    }

    return ob_get_clean();
}

add_shortcode('woocommerce_custom_page', 'woocommerce_custom_page_shortcode_updated');